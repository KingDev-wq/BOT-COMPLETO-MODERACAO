const { EmbedBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./databases/configBoost.json" });

module.exports = {
  name: "guildMemberUpdate",
  run: async (oldMember, newMember, client) => {
    try {
      const isEnabled = db.get("enabled");
      if (!isEnabled) return;

      const hadBoost = oldMember.premiumSince;
      const hasBoost = newMember.premiumSince;

      if (!hadBoost && hasBoost) {
        console.log(`[LOG] Boost detectado por ${newMember.user.tag} (${newMember.user.id})`);

        const channelId = db.get("channelId");
        if (!channelId) {
          console.log("[LOG] Nenhum ID de canal configurado.");
          return;
        }

        const channel = newMember.guild.channels.cache.get(channelId);
        if (!channel) {
          console.log("[LOG] Canal configurado não encontrado ou inválido.");
          return;
        }

        if (!channel.permissionsFor(newMember.guild.members.me).has("SendMessages")) {
          console.log("[LOG] Permissão de envio de mensagens ausente no canal configurado.");
          return;
        }

        let desc = db.get("description");
        desc = desc
          .replace("{user}", `${newMember}`)
          .replace("{username}", `${newMember.user.username}`)
          .replace("{userid}", `${newMember.user.id}`)
          .replace("{guildid}", `${newMember.guild.id}`)
          .replace("{guildname}", `${newMember.guild.name}`)
          .replace("{membros}", `${newMember.guild.memberCount}`);

        const embed = new EmbedBuilder()
          .setTitle(db.get("title") || "🎉 Obrigado pelo Boost!")
          .setDescription(desc || `Muito obrigado pelo boost, ${newMember}! 🚀`)
          .setColor(db.get("color") || "#FF73FA")
          .setFooter({
            text: db.get("footer") || "Seu suporte ajuda o servidor a crescer!",
            iconURL: newMember.user.displayAvatarURL({ dynamic: true, size: 1024 }),
          })
          .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true, size: 1024 }));

        const imageUrl = db.get("image");
        if (imageUrl) {
          embed.setImage(imageUrl);
        }

        await channel.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error("[LOG] Erro ao processar o evento de boost:", error);
    }
  },
};