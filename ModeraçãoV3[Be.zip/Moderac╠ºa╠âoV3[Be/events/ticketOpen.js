const { Events, ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, ComponentType } = require('discord.js');
const fs = require('fs');
const { QuickDB } = require('quick.db');
const db = new QuickDB();
const configPath = './databases/ticketGeral.json';

module.exports = {
    name: Events.InteractionCreate,
    async run(interaction) {
        if (!interaction.isButton() || interaction.customId !== 'abrirTicket') return;

        await interaction.reply({ content: '🔁 | Estamos criando seu ticket, Aguarde...', ephemeral: true });

        let categoriaId, suporteId;
        try {
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            categoriaId = config.ticket_categoria;
            suporteId = config.ticket_cargo;

            if (!categoriaId || !suporteId) throw new Error(`IDs obrigatórios ausentes.`);
        } catch {
            return interaction.editReply({ content: '❌ | Sistema não configurado. Contate um administrador.', ephemeral: true });
        }

        const existingTicket = interaction.guild.channels.cache.find(
            (channel) =>
                channel.name.startsWith('📂・') &&
                channel.permissionOverwrites.cache.has(interaction.user.id)
        );

        if (existingTicket) {
            return interaction.editReply({ content: '❌ | Você já possui um ticket aberto.', ephemeral: true });
        }

        try {
            const ticketChannel = await interaction.guild.channels.create({
                name: `📂・${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: categoriaId,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
                    { id: suporteId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
                ],
            });
          
          const ticketData = {

    channelId: ticketChannel.id,

    ownerId: interaction.user.id,

    status: '🟡 Pendente',

    assumidoPor: null,

};
          
await db.set(`ticket_${ticketChannel.id}`, ticketData);

            const embed = new EmbedBuilder()

    .setTitle(`${interaction.guild.name} | Administração`)

    .setDescription('**Status do Ticket**\n🟡 | Pendente\n\n**Assumido Por:**\nNinguém Assumiu')

    .setColor(0x2f3136)

    .setFooter({ text: `Criador do Ticket: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

            const painel = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('painelStaff').setLabel('Painel Staff').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('assumirTicket').setLabel('📋 Assumir').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('fecharTicket').setLabel('❌ Fechar').setStyle(ButtonStyle.Danger)
            );

            await ticketChannel.send({
                embeds: [embed],
                components: [painel],
            });

            await interaction.editReply({ content: `📂 | Ticket criado com sucesso: ${ticketChannel}`, ephemeral: true });

            const collector = ticketChannel.createMessageComponentCollector({ componentType: ComponentType.Button });

            let assumidoPor = null;

            collector.on('collect', async (buttonInteraction) => {
                if (!buttonInteraction.member.roles.cache.has(suporteId)) {
                    return buttonInteraction.reply({ content: '❌ | Você não tem permissão para usar este botão.', ephemeral: true });
                }

                if (buttonInteraction.customId === 'painelStaff') {
                    const selectMenu = new ActionRowBuilder().addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('staffMenu')
                            .setPlaceholder('Escolha uma ação')
                            .addOptions(
                                { label: 'Renomear Ticket', value: 'renomearTicket' },
                                { label: 'Notificar Usuário', value: 'notificarUsuario' },
                                { label: 'Adicionar Membro', value: 'adicionarMembro' },
                                { label: 'Remover Membro', value: 'removerMembro' }
                            )
                    );
                    return buttonInteraction.reply({ content: 'Selecione uma ação:', components: [selectMenu], ephemeral: true });
                }

                if (buttonInteraction.customId === 'assumirTicket') {


    if (assumidoPor === buttonInteraction.user.id) {

        return buttonInteraction.reply({ content: '❌ | Você já assumiu este ticket.', ephemeral: true });

    }

    if (assumidoPor) {

        return buttonInteraction.reply({ content: '❌ | Este ticket já foi assumido por outro membro.', ephemeral: true });

    }


    assumidoPor = buttonInteraction.user.id;

    await db.set(`ticket_${ticketChannel.id}.status`, '🟢 Assumido');

    await db.set(`ticket_${ticketChannel.id}.assumidoPor`, assumidoPor);


    const embedAtualizado = EmbedBuilder.from(embed).setDescription(

        `**Status do Ticket**\n🟢 | Assumido\n\n**Assumido Por:**\n${buttonInteraction.user.tag}`

    );


    const pinnedMessage = await ticketChannel.messages.fetchPinned().then((pinned) => pinned.first());

    if (pinnedMessage) {


        await pinnedMessage.edit({ embeds: [embedAtualizado] });

    } else {


        const recentMessage = await ticketChannel.messages.fetch({ limit: 10 }).then((messages) =>

            messages.find((msg) => msg.embeds.length > 0 && msg.embeds[0].title?.includes('Administração'))

        );

        if (recentMessage) {

            await recentMessage.edit({ embeds: [embedAtualizado] });

        }

    }

    return buttonInteraction.reply({ content: '✅ | Você assumiu o ticket com sucesso.', ephemeral: true });

}

                if (buttonInteraction.customId === 'fecharTicket') {

    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

    const logChannelId = config.ticket_log_channel;

    if (!logChannelId) {

        return buttonInteraction.reply({ content: '❌ | Canal de logs não configurado.', ephemeral: true });

    }

    const logChannel = interaction.guild.channels.cache.get(logChannelId);

    if (!logChannel) {

        return buttonInteraction.reply({ content: '❌ | O canal de logs configurado não existe.', ephemeral: true });

    }


    const messages = await ticketChannel.messages.fetch({ limit: 100 });

    const transcript = messages.map(msg => `${msg.author.tag}: ${msg.content || '[Embed/Mensagem Anexada]'}`).reverse().join('\n');

    const assumidoPorUsuario = assumidoPor 

        ? `<@${assumidoPor}>` 

        : 'Não Assumido';

    const logEmbed = new EmbedBuilder()

        .setTitle('Log de Ticket')

        .setDescription(

            `**Status do Ticket:**\n${assumidoPor ? '🟢 | Assumido' : '🟡 | Pendente'}\n\n` +

            `**Assumido Por:**\n${assumidoPorUsuario}\n\n` +

            `**Hora:**\n${new Date().toLocaleTimeString('pt-BR')}\n\n` +

            `**Data de Fechamento:**\n${new Date().toLocaleDateString('pt-BR')}`

        )

        .setColor(0x2f3136)

        .setFooter({ text: `Ticket fechado por: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });


    await logChannel.send({

        embeds: [logEmbed],

        files: [

            {

                attachment: Buffer.from(transcript, 'utf-8'),

                name: `transcript_${ticketChannel.name}.txt`

            }

        ]

    });
                  
                  await db.delete(`ticket_${ticketChannel.id}`);

    await buttonInteraction.reply({ content: `🔁 | Apagando ticket de ${interaction.user.tag}, aguarde **5 segundos**…` });

    setTimeout(() => ticketChannel.delete(), 5000);

}
            });

            const menuCollector = ticketChannel.createMessageComponentCollector({ componentType: ComponentType.StringSelect });

            menuCollector.on('collect', async (menuInteraction) => {
                if (!menuInteraction.member.roles.cache.has(suporteId)) {
                    return menuInteraction.reply({ content: '❌ | Você não tem permissão para usar este menu.', ephemeral: true });
                }

                if (menuInteraction.values[0] === 'removerMembro') {

    await menuInteraction.reply({ content: 'Mencione o usuário a ser removido do ticket.', ephemeral: true });

    const filter = (msg) => msg.author.id === menuInteraction.user.id;

    const messageCollector = ticketChannel.createMessageCollector({ filter, time: 60000 });

    messageCollector.on('collect', async (message) => {

        const user = message.mentions.users.first();


        if (!user) {

            await message.reply({ content: '❌ | Você deve mencionar um usuário válido.', ephemeral: true });

            messageCollector.stop('invalid_mention');

            return;

        }


        const memberInTicket = ticketChannel.permissionOverwrites.cache.has(user.id);

        if (!memberInTicket) {

            await message.reply({ content: '❌ | O usuário não está no ticket.', ephemeral: true });

            messageCollector.stop('not_in_ticket');

            return;

        }


        if (user.id === interaction.user.id) {

            await message.reply({ content: '❌ | Você não pode remover o dono do ticket.', ephemeral: true });

            messageCollector.stop('owner_removal');

            return;

        }

        try {


            await ticketChannel.permissionOverwrites.delete(user.id);

            await message.reply({ content: `✅ | Usuário **${user.tag}** foi removido do ticket.` });

            await menuInteraction.editReply({ content: `✅ | Usuário **${user.tag}** removido com sucesso.`, ephemeral: true });

            messageCollector.stop('success');

        } catch (error) {

            await menuInteraction.editReply({ content: '❌ | Erro ao remover o usuário. Verifique as permissões do canal.', ephemeral: true });

            messageCollector.stop('error');

        }

    });

    messageCollector.on('end', (_, reason) => {

        if (reason === 'time') {

            menuInteraction.editReply({ content: '❌ | Tempo esgotado, ação cancelada.', ephemeral: true });

        } else if (reason === 'invalid_mention') {

            menuInteraction.editReply({ content: '❌ | Menção inválida detectada. Reinicie a ação para tentar novamente.', ephemeral: true });

        } else if (reason === 'not_in_ticket') {

            menuInteraction.editReply({ content: '❌ | O usuário não está neste ticket. Reinicie a ação para tentar novamente.', ephemeral: true });

        } else if (reason === 'owner_removal') {

            menuInteraction.editReply({ content: '❌ | Não é possível remover o dono do ticket. Reinicie a ação para tentar novamente.', ephemeral: true });

        }

    });

}
              
              if (menuInteraction.values[0] === 'adicionarMembro') {

    await menuInteraction.reply({ content: 'Mencione o usuário que deseja adicionar ao ticket.', ephemeral: true });

    const filter = (msg) => msg.author.id === menuInteraction.user.id;

    const messageCollector = ticketChannel.createMessageCollector({ filter, time: 60000 });

    messageCollector.on('collect', async (message) => {

        const user = message.mentions.users.first();


        if (!user) {

            await message.reply({ content: '❌ | Você deve mencionar um usuário válido.', ephemeral: true });

            messageCollector.stop('invalid_mention');

            return;

        }


        if (!message.guild.members.cache.has(user.id)) {

            await message.reply({ content: '❌ | O usuário mencionado não faz parte do servidor.', ephemeral: true });

            messageCollector.stop('invalid_mention');

            return;

        }


        const memberInTicket = ticketChannel.permissionOverwrites.cache.has(user.id);

        if (memberInTicket) {

            await message.reply({ content: '❌ | O usuário já está neste ticket.', ephemeral: true });

            messageCollector.stop('invalid_mention');

            return;

        }

        try {


            await ticketChannel.permissionOverwrites.create(user.id, {

                ViewChannel: true,

                SendMessages: true,

                ReadMessageHistory: true,

            });

            await message.reply({ content: `✅ | Usuário **${user.tag}** foi adicionado ao ticket.` });

            await menuInteraction.editReply({ content: `✅ | Usuário **${user.tag}** adicionado com sucesso.`, ephemeral: true });

            messageCollector.stop('success');

        } catch (error) {

            await menuInteraction.editReply({ content: '❌ | Erro ao adicionar o usuário. Verifique as permissões do canal.', ephemeral: true });

            messageCollector.stop('error');

        }

    });

    messageCollector.on('end', (_, reason) => {

        if (reason === 'time') {

            menuInteraction.editReply({ content: '❌ | Tempo esgotado, ação cancelada.', ephemeral: true });

        } else if (reason === 'invalid_mention') {

            menuInteraction.editReply({ content: '❌ | Menção inválida detectada. Reinicie a ação para tentar novamente.', ephemeral: true });

        }

    });

}
              
              if (menuInteraction.values[0] === 'renomearTicket') {

    await menuInteraction.reply({ content: 'Digite o novo nome para o ticket (até 14 caracteres, sem emojis).', ephemeral: true });

    const filter = (msg) => msg.author.id === menuInteraction.user.id;

    const messageCollector = ticketChannel.createMessageCollector({ filter, time: 60000 });

    messageCollector.on('collect', async (message) => {

        const novoNome = message.content.trim();


        const emojiRegex = /(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/gu;


        if (novoNome.length > 14) {

            await message.reply({ content: '❌ | O nome do ticket não pode ter mais de 14 caracteres. Tente novamente.', ephemeral: true });

            messageCollector.stop('exceeds_length');

            return;

        }


        if (emojiRegex.test(novoNome)) {

            await message.reply({ content: '❌ | O nome do ticket não pode conter emojis. Tente novamente.', ephemeral: true });

            messageCollector.stop('emoji_detected');

            return;

        }


        const nomeFinal = `📂・${novoNome}「${menuInteraction.user.username}」`;

        try {

            await ticketChannel.setName(nomeFinal);

            await message.reply({ content: `✅ | Ticket renomeado para **${nomeFinal}**.` });

            await menuInteraction.editReply({ content: `✅ | Ticket renomeado para **${nomeFinal}**.`, ephemeral: true });

        } catch (error) {

            await menuInteraction.editReply({ content: '❌ | Erro ao renomear o ticket. Verifique as permissões.', ephemeral: true });

        }

        messageCollector.stop('success');

    });

    messageCollector.on('end', (_, reason) => {

        if (reason === 'time') {

            menuInteraction.editReply({ content: '❌ | Tempo esgotado, ação cancelada.', ephemeral: true });

        } else if (reason === 'emoji_detected') {

            menuInteraction.editReply({ content: '❌ | Nome inválido. Emojis detectados. Reinicie a ação para tentar novamente.', ephemeral: true });

        } else if (reason === 'exceeds_length') {

            menuInteraction.editReply({ content: '❌ | Nome inválido. O nome excede 14 caracteres. Reinicie a ação para tentar novamente.', ephemeral: true });

        }

    });

}

                if (menuInteraction.values[0] === 'notificarUsuario') {

    const notificationEmbed = new EmbedBuilder()

        .setDescription(`❗️ | Um staff está lhe chamando no servidor **${menuInteraction.guild.name}**.`)

        .setColor(0xffa500);

    const redirectButton = new ActionRowBuilder().addComponents(

        new ButtonBuilder()

            .setLabel('Acessar Ticket')

            .setStyle(ButtonStyle.Link)

            .setURL(ticketChannel.url)

    );

    const ticketOwner = await menuInteraction.guild.members.fetch(interaction.user.id).catch(() => null);

    if (!ticketOwner) {

        return menuInteraction.reply({ 

            content: '❌ | Não foi possível localizar o dono do ticket no servidor.', 

            ephemeral: true 

        });

    }

    ticketOwner.send({ 

        embeds: [notificationEmbed], 

        components: [redirectButton] 

    })

        .then(() => {

            menuInteraction.reply({ 

                content: '✅ | Usuário notificado com sucesso.', 

                ephemeral: true 

            });

        })

        .catch(() => {

            menuInteraction.reply({ 

                content: '❌ | Não foi possível notificar o usuário. Ele pode ter desativado mensagens diretas.', 

                ephemeral: true 

            });

        });

}
            });
        } catch (error) {

    console.error('Erro ao criar o ticket:', error);

    await interaction.editReply({ content: '❌ | Erro ao criar o ticket. Contate um administrador.', ephemeral: true });

}
    },
};