const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute um usuário oficialmente no Discord.')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('O usuário a ser mutado.')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (!dbPerms.has(interaction.user.id)) {
    return interaction.reply({
        content: '❌ | Você não possui permissão para usar este comando.',
        ephemeral: true
    });
}
      
    const usuario = interaction.options.getUser('usuario');
    const membro = interaction.guild.members.cache.get(usuario.id);

    if (!membro) {
      return interaction.reply({ content: '⚠️ Usuário não encontrado no servidor.', ephemeral: true });
    }
    if (membro.permissions.has('Administrator')) {
      return interaction.reply({ content: '⚠️ Você não pode mutar um administrador.', ephemeral: true });
    }

    const tempos = [
      { label: '60 segundos', value: '60', emoji: '⏱️' },
      { label: '5 minutos', value: '300', emoji: '🕔' },
      { label: '10 minutos', value: '600', emoji: '🕙' },
      { label: '30 minutos', value: '1800', emoji: '🕧' },
      { label: '1 hora', value: '3600', emoji: '🕒' },
      { label: '24 horas', value: '86400', emoji: '🕛' }
    ];

    const menuTempo = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('selecionar_tempo')
        .setPlaceholder('⏳ Escolha o tempo de mute')
        .addOptions(tempos)
    );

    await interaction.reply({
      content: `Escolha o tempo para aplicar o mute oficial em ${usuario}.`,
      components: [menuTempo],
      ephemeral: true
    });

    const collector = interaction.channel.createMessageComponentCollector({ time: 60000 });

    let tempoSelecionado = null;

    collector.on('collect', async i => {
      if (i.customId === 'selecionar_tempo') {
        tempoSelecionado = i.values[0];

        const botoes = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('voltar')
            .setLabel('🔄 Voltar')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('confirmar')
            .setLabel('✅ Confirmar')
            .setStyle(ButtonStyle.Success)
        );

        await i.update({
          content: `⏳ Você escolheu ${tempos.find(t => t.value === tempoSelecionado).label}. Confirma?`,
          components: [botoes]
        });
      } else if (i.customId === 'voltar') {
        tempoSelecionado = null;

        await i.update({
          content: `Escolha o tempo para aplicar o mute oficial em ${usuario}.`,
          components: [menuTempo]
        });
      } else if (i.customId === 'confirmar') {
        try {
          const tempoMs = parseInt(tempoSelecionado) * 1000;
          await membro.timeout(tempoMs, `Mutado por ${interaction.user.tag}`);

          // Emitir evento de mutar
          console.log('Tentando emitir o evento mutarUsers:', {
            usuario: usuario.id,
            moderador: interaction.user.id,
            tempo: tempoMs,
          });

          // Emissão do evento
          interaction.client.emit('mutarUsers', usuario, interaction.user, interaction.guild, tempoMs);

          await i.update({
            content: `🔇 ${usuario} foi mutado oficialmente por ${tempos.find(t => t.value === tempoSelecionado).label}.`,
            components: []
          });
        } catch (error) {
          console.error(error);
          await i.update({
            content: '❌ Ocorreu um erro ao tentar mutar o usuário.',
            components: []
          });
        }
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        interaction.editReply({ content: '⏹️ Comando cancelado por inatividade.', components: [] });
      }
    });
  }
};