const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Desmutar um usuário oficialmente no Discord.')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('O usuário a ser desmutado.')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}
    
    const usuario = interaction.options.getUser('usuario');
    const membro = await interaction.guild.members.fetch(usuario.id).catch(() => null);

    if (!membro) {
      return interaction.reply({ content: '⚠️ Usuário não encontrado no servidor.', ephemeral: true });
    }

    if (!membro.isCommunicationDisabled()) {
      return interaction.reply({ content: '⚠️ Este usuário não está mutado.', ephemeral: true });
    }

    const botoes = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirmar')
        .setLabel('✅ Confirmar')
        .setStyle(ButtonStyle.Success)
    );

    await interaction.reply({
      content: `🛑 Você deseja desmutar ${usuario}?`,
      components: [botoes],
      ephemeral: true
    });

    const collector = interaction.channel.createMessageComponentCollector({
      filter: i => i.customId === 'confirmar' && i.user.id === interaction.user.id,
      max: 1,
      time: 60000
    });

    collector.on('collect', async i => {
      try {
        await membro.timeout(null);

        await interaction.editReply({
          content: `🔓 ${usuario} foi desmutado com sucesso.`,
          components: []
        });

        interaction.client.emit('desmutarUsers', usuario, interaction.user, interaction.guild);
      } catch (error) {

        await interaction.editReply({
          content: '❌ Ocorreu um erro ao tentar desmutar o usuário.',
          components: []
        });
        console.error(error);
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        interaction.editReply({ content: '⏹️ Comando cancelado por inatividade.', components: [] });
      }
    });
  }
};