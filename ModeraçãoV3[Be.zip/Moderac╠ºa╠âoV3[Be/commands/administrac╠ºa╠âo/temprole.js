const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('temp-role')
    .setDescription('Atribui um cargo temporário a um membro')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('Selecione o usuário')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('cargo')
        .setDescription('Selecione o cargo')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('valor')
        .setDescription('Quantos dias, horas ou minutos o cargo será atribuído')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('unidade')
        .setDescription('Escolha a unidade de tempo (dias, horas, minutos)')
        .setRequired(true)
        .addChoices(
          { name: 'Dias', value: 'dias' },
          { name: 'Horas', value: 'horas' },
          { name: 'Minutos', value: 'minutos' }
        )),

  async execute(interaction) {
    const user = interaction.options.getMember('usuario');
    const role = interaction.options.getRole('cargo');
    const value = interaction.options.getInteger('valor');
    const unidade = interaction.options.getString('unidade');

    if (!interaction.member.permissions.has('ManageRoles')) {
      return interaction.reply({ content: 'Você não tem permissão para usar este comando.', ephemeral: true });
    }

    // Calcula o tempo em milissegundos
    let durationMs;
    switch (unidade) {
      case 'dias':
        durationMs = value * 24 * 60 * 60 * 1000;
        break;
      case 'horas':
        durationMs = value * 60 * 60 * 1000;
        break;
      case 'minutos':
        durationMs = value * 60 * 1000;
        break;
      default:
        return interaction.reply({ content: 'Unidade de tempo inválida.', ephemeral: true });
    }

    try {
      // Adiciona o cargo
      await user.roles.add(role);
      interaction.reply({ content: `Cargo ${role.name} adicionado ao usuário ${user.user.tag} por ${value} ${unidade}.` });

      // Remove o cargo após o tempo especificado
      setTimeout(async () => {
        if (user.roles.cache.has(role.id)) {
          await user.roles.remove(role);
          console.log(`Cargo ${role.name} removido de ${user.user.tag}.`);
        }
      }, durationMs);
    } catch (error) {
      console.error(error);
      interaction.reply({ content: 'Houve um erro ao adicionar o cargo. Verifique as permissões do bot.', ephemeral: true });
    }
  },
};