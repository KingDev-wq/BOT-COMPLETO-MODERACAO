const { SlashCommandBuilder } = require('discord.js');
const { JsonDatabase } = require('wio.db');
const config = require('../../config.json');
const Discord = require('discord.js');
const perms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('perms')
        .setDescription('Adicione ou remova as permissões'),

    async execute(interaction) {
        if (interaction.user.id !== config.ownerID) {
            return interaction.reply({ content: `👑 | Apenas o dono do bot pode usar isso!`, ephemeral: true });
        }

        const row = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('adicionar')
                    .setLabel('Adicionar')
                    .setStyle(3)
                    .setEmoji('1285374627878539345'),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('remover')
                    .setLabel('Remover')
                    .setStyle(4)
                    .setEmoji('1275914097292087441'),
            );

        const embed = await interaction.reply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle(`Configuração das permissões`)
                .setDescription(`**Adicione e remova permissões usando este comando.**`)
                .setColor('Aqua')
                .setFooter({ text: `Adicione e remova perms.` })
            ],
            components: [row]
        });

        const interação = interaction.channel.createMessageComponentCollector({
            componentType: Discord.ComponentType.Button,
            time: 120000,
        });

        interação.on("collect", async (i) => {
            if (i.user.id !== interaction.user.id) {
                return i.reply({ content: "❌ | Apenas quem executou o comando pode interagir com esses botões.", ephemeral: true });
            }

            if (i.customId === "adicionar" || i.customId === "remover") {
                i.deferUpdate();
                const action = i.customId === "adicionar" ? "dar permissão" : "remover permissão";
                const operation = i.customId === "adicionar" ? perms.set : perms.delete;
                const emoji = i.customId === "adicionar" ? "🟢" : "🔴";

                i.channel.send(`❓️ | Mencione o usuário para ${action}.`).then(msg => {
                    const filter = m => m.author.id === interaction.user.id;
                    const collector = msg.channel.createMessageCollector({ filter, max: 1, time: 60000 });

                    collector.on("collect", message => {
                        const user = message.mentions.users.first();
                        if (!user) {
                            return msg.edit("❌ | Você precisa mencionar um usuário válido!").then((editedMessage) => {
                                setTimeout(() => {
                                    editedMessage.delete().catch(console.error);
                                }, 5000);
                            });
                        }

                        const userID = user.id;
                        message.delete();

                        if (i.customId === "adicionar") {
                            if (perms.has(userID)) {
                                return msg.edit(`⚠️ | Este usuário já possui permissão! Consulte \`/permlist\`.`).then((editedMessage) => {
                                    setTimeout(() => {
                                        editedMessage.delete().catch(console.error);
                                    }, 5000);
                                });
                            }
                            operation.call(perms, `${userID}`, userID);
                            msg.edit(`${emoji} | Permissão adicionada para o usuário!`).then((editedMessage) => {
                                setTimeout(() => {
                                    editedMessage.delete().catch(console.error);
                                }, 2500);
                            });
                        } else if (i.customId === "remover") {
                            if (!perms.has(userID)) {
                                return msg.edit(`⚠️ | Este usuário não possui permissão! Consulte \`/permlist\`.`).then((editedMessage) => {
                                    setTimeout(() => {
                                        editedMessage.delete().catch(console.error);
                                    }, 5000);
                                });
                            }
                            operation.call(perms, `${userID}`);
                            msg.edit(`${emoji} | Permissão removida do usuário!`).then((editedMessage) => {
                                setTimeout(() => {
                                    editedMessage.delete().catch(console.error);
                                }, 2500);
                            });
                        }

                        const embednew = new Discord.EmbedBuilder()
                            .setTitle(`Configuração das permissões`)
                            .setDescription(`**Adicione e remova permissões usando este comando.**`)
                            .setColor('Aqua')
                            .setFooter({ text: `Adicione e remova perms.` });
                        embed.edit({ embeds: [embednew] });
                    });

                    collector.on("end", (collected, reason) => {
                        if (reason === "time") {
                            msg.edit(`⏳ | Tempo esgotado! Você demorou muito para mencionar um usuário.`).then((editedMessage) => {
                                setTimeout(() => {
                                    editedMessage.delete().catch(console.error);
                                }, 5000);
                            });
                        }
                    });
                });
            }
        });

        interação.on("end", () => {
            embed.edit({ components: [] });
        });
    }
};