const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botconfig')
    .setDescription('[⚙️] Configure o bot através de um painel interativo.'),

  async execute(interaction) {
    if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}

    const embed = new EmbedBuilder()
      .setTitle('Painel de Configuração do Bot')
      .setDescription('Selecione uma das opções abaixo para configurar o bot:')
      .setColor('#5865F2')
      .setFooter({ text: `Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('change_name')
        .setLabel('📝 Alterar Nome')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('change_avatar')
        .setLabel('🖼️ Alterar Foto')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
    );

    await interaction.reply({ embeds: [embed], components: [buttons], ephemeral: true });
  },
};