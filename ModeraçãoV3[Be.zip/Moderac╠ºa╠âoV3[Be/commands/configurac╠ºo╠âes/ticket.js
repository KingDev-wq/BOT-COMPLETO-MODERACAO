const { 

    SlashCommandBuilder, 

    ActionRowBuilder, 

    ButtonBuilder, 

    ButtonStyle, 

    ModalBuilder, 

    TextInputBuilder, 

    TextInputStyle, 

    StringSelectMenuBuilder, 

    ChannelType, 

    PermissionsBitField, 

    EmbedBuilder

} = require('discord.js');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/ticketGeral.json' });
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Sistema de configuração de tickets'),

    async execute(interaction) {
        if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}

        const painel1 = new ActionRowBuilder()

    .addComponents(

        new ButtonBuilder().setCustomId('configEmbed').setLabel('🖊️ Configurar Embed').setStyle(ButtonStyle.Primary),

        new ButtonBuilder().setCustomId('configMsg').setLabel('💬 Configurar Mensagem').setStyle(ButtonStyle.Primary),

        new ButtonBuilder().setCustomId('configCategoria').setLabel('📂 Configurar Categoria').setStyle(ButtonStyle.Primary),

        new ButtonBuilder().setCustomId('configLogChannel').setLabel('📝 Configurar Canal de Logs').setStyle(ButtonStyle.Secondary),

        new ButtonBuilder().setCustomId('configCargo').setLabel('⚙️ Configurar Cargo de Suporte').setStyle(ButtonStyle.Secondary)

    );

        const painel2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('resetEmbed').setLabel('🔄 Resetar Embed').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('resetMsg').setLabel('🔄 Resetar Mensagem').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('postarPainel').setLabel('📤 Postar Painel').setStyle(ButtonStyle.Success)
            );

        const embed = new EmbedBuilder()

    .setTitle('Bem-vindo ao painel de **Gerenciamento de Tickets**')

    .setDescription('O sistema de ticket permite configurar embed, mensagem, categorias, cargo de suporte e o canal onde o painel será exibido, garantindo controle e personalização. \n\n ⚠️ Se você Tiver 40 Tickets Abertos e Reiniciar o bot, Todos os Tickets Irão Parar de Funcionar, Mais [TUDO] Está Funcionando Perfeitamente, Está Versão é a Versão [Beta] Qualquer Erro Contate-á @nerydev')

    .setColor('#FF5733')

    .setFooter({ text: 'Sistema de Tickets', iconURL: interaction.client.user.displayAvatarURL() });

await interaction.reply({

    embeds: [embed],

    components: [painel1, painel2],

    ephemeral: true

});

        const collector = interaction.channel.createMessageComponentCollector({ time: 300000 });

        collector.on('collect', async (i) => {
            if (i.customId === 'configEmbed') {
                const modal = new ModalBuilder()
                    .setCustomId('configEmbedModal')
                    .setTitle('Configurar Embed')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('titulo').setLabel('Título').setStyle(TextInputStyle.Short).setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('descricao').setLabel('Descrição').setStyle(TextInputStyle.Paragraph).setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('cor').setLabel('Cor (Hexadecimal)').setStyle(TextInputStyle.Short).setRequired(false)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('imagem').setLabel('URL da Imagem').setStyle(TextInputStyle.Short).setRequired(false)
                        )
                    );

                await i.showModal(modal);

                const modalSubmit = await i.awaitModalSubmit({ time: 60000 });

                const titulo = modalSubmit.fields.getTextInputValue('titulo');
                const descricao = modalSubmit.fields.getTextInputValue('descricao');
                const cor = modalSubmit.fields.getTextInputValue('cor') || null;
                const imagem = modalSubmit.fields.getTextInputValue('imagem') || null;

                if (cor && !/^#[0-9A-Fa-f]{6}$/.test(cor)) {
                    return modalSubmit.reply({ content: '❌ Cor inválida. Use um código hexadecimal (ex: #FFFFFF).', ephemeral: true });
                }
                if (imagem && !imagem.startsWith('https://')) {
                    return modalSubmit.reply({ content: '❌ URL da imagem inválida. Deve começar com "https://".', ephemeral: true });
                }

                db.set('ticket_embed', { titulo, descricao, cor, imagem });
                modalSubmit.reply({ content: '✅ Embed configurada com sucesso!', ephemeral: true });
            }

            if (i.customId === 'configMsg') {
                const modal = new ModalBuilder()
                    .setCustomId('configMsgModal')
                    .setTitle('Configurar Mensagem')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('mensagem')
                                .setLabel('Mensagem (Máximo 4000 caracteres)')
                                .setStyle(TextInputStyle.Paragraph)
                                .setMaxLength(4000)
                                .setRequired(true)
                        )
                    );

                await i.showModal(modal);

                const modalSubmit = await i.awaitModalSubmit({ time: 60000 });
                const mensagem = modalSubmit.fields.getTextInputValue('mensagem');

                db.set('ticket_mensagem', mensagem);
                modalSubmit.reply({ content: '✅ Mensagem configurada com sucesso!', ephemeral: true });
            }

            if (i.customId === 'configCategoria') {
                const categorias = interaction.guild.channels.cache
                    .filter(channel => channel.type === ChannelType.GuildCategory)
                    .map(channel => ({
                        label: channel.name,
                        value: channel.id
                    }));

                if (categorias.length === 0) {
                    return i.reply({ content: '❌ Nenhuma categoria encontrada no servidor.', ephemeral: true });
                }

                const menu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('categoriaMenu')
                        .setPlaceholder('Selecione uma categoria')
                        .addOptions(categorias)
                );

                await i.reply({ content: 'Selecione a categoria para os tickets:', components: [menu], ephemeral: true });

                const menuCollector = i.channel.createMessageComponentCollector({
                    filter: m => m.customId === 'categoriaMenu' && m.user.id === interaction.user.id,
                    time: 60000,
                    max: 1
                });

                menuCollector.on('collect', async (menuInteraction) => {
                    const categoriaSelecionada = menuInteraction.values[0];
                    const categoria = interaction.guild.channels.cache.get(categoriaSelecionada);

                    db.set('ticket_categoria', categoria.id);

                    await menuInteraction.update({
                        content: `✅ Categoria configurada para: **${categoria.name}**.`,
                        components: []
                    });
                });
            }
          
          if (i.customId === 'configLogChannel') {

    await i.reply({ content: 'Mencione o canal de logs desejado.', ephemeral: true });

    const filter = m => m.author.id === interaction.user.id;

    try {

        const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000 });

        const logChannel = collected.first().mentions.channels.first();

        if (!logChannel || logChannel.type !== ChannelType.GuildText) {

            return i.followUp({ content: '❌ Você mencionou um canal inválido. Certifique-se de que é um canal de texto.', ephemeral: true });

        }

        db.set('ticket_log_channel', logChannel.id);

        i.followUp({ content: `✅ Canal de logs configurado para: **${logChannel.name}**.`, ephemeral: true });

    } catch (error) {

        i.followUp({ content: '⏰ Tempo esgotado. Você não mencionou um canal a tempo.', ephemeral: true });

    }

}

            if (i.customId === 'configCargo') {
                await i.reply({ content: 'Mencione o cargo de suporte desejado.', ephemeral: true });

                const filter = m => m.author.id === interaction.user.id;
                const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000 });
                const cargo = collected.first().mentions.roles.first();

                if (!cargo) {
                    return i.followUp({ content: '❌ Você mencionou um cargo inválido ou não mencionou.', ephemeral: true });
                }

                db.set('ticket_cargo', cargo.id);
                i.followUp({ content: `✅ Cargo de suporte configurado para: **${cargo.name}**.`, ephemeral: true });
            }

            if (i.customId === 'resetEmbed') {
                db.delete('ticket_embed');
                i.reply({ content: '🔄 Configuração da embed foi resetada.', ephemeral: true });
            }

            if (i.customId === 'resetMsg') {
                db.delete('ticket_mensagem');
                i.reply({ content: '🔄 Configuração da mensagem foi resetada.', ephemeral: true });
            }

            if (i.customId === 'postarPainel') {
                const embedConfig = db.get('ticket_embed');
                const msgConfig = db.get('ticket_mensagem');

                if (embedConfig && msgConfig) {
                    return i.reply({ content: '❌ Apenas uma configuração pode ser enviada. Resete a embed ou a mensagem.', ephemeral: true });
                }
                if (!embedConfig && !msgConfig) {
                    return i.reply({ content: '❌ Configure a embed ou a mensagem antes de postar o painel.', ephemeral: true });
                }

                await i.reply({ content: 'Mencione o canal onde deseja postar o painel.', ephemeral: true });

                const filter = m => m.author.id === interaction.user.id;
                const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000 });
                const canal = collected.first().mentions.channels.first();

                if (!canal || canal.type !== ChannelType.GuildText) {
                    return i.followUp({ content: '❌ Você mencionou um canal inválido. Certifique-se de que é um canal de texto.', ephemeral: true });
                }

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('abrirTicket').setLabel('📩 Abrir Ticket').setStyle(ButtonStyle.Success)
                );

                if (embedConfig) {
                    const embed = {
                        title: embedConfig.titulo,
                        description: embedConfig.descricao,
                        color: embedConfig.cor ? parseInt(embedConfig.cor.replace('#', ''), 16) : null,
                        image: embedConfig.imagem ? { url: embedConfig.imagem } : null,
                    };
                    canal.send({ embeds: [embed], components: [row] });
                } else {
                    canal.send({ content: msgConfig, components: [row] });

                }

                i.followUp({ content: `✅ Painel de tickets enviado para o canal ${canal}.`, ephemeral: true });

            }

        });

        collector.on('end', (collected, reason) => {

            if (reason === 'time') {

                interaction.editReply({

                    content: '⏰ Tempo para configurar o sistema expirou.',

                    components: []

                });

            }

        });

    },

};