const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField } = require('discord.js');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase();
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('selectcargo')
        .setDescription('Gerencia cargos e embeds automáticos'),

    async execute(interaction) {
        if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}

        const painelEmbed = new EmbedBuilder()
            .setTitle('📋 Gerenciamento de Cargos e Embeds')
            .setDescription('Selecione abaixo a ação que deseja realizar:')
            .setColor('#0099ff')
            .addFields(
                { name: '⚙️ Configurar Cargo', value: 'Defina o cargo que será usado.', inline: true },
                { name: '🖊️ Configurar Embed', value: 'Personalize a mensagem embed.', inline: true },
                { name: '📤 Postar Embed', value: 'Envie a embed configurada.', inline: true }
            )
            .setFooter({ text: 'Gerenciamento de Cargos', iconURL: interaction.client.user.displayAvatarURL() });

        const painel = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('painelSelect')
                    .setPlaceholder('Selecione uma ação')
                    .addOptions([
                        { label: '⚙️ Configurar Cargo', value: 'configCargo', description: 'Definir um cargo para a configuração' },
                        { label: '🖊️ Configurar Embed', value: 'configEmbed', description: 'Criar ou editar uma embed personalizada' },
                        { label: '📤 Postar Embed', value: 'postarEmbed', description: 'Publicar a embed configurada' }
                    ])
            );

        await interaction.reply({ embeds: [painelEmbed], components: [painel], ephemeral: true });

        const collector = interaction.channel.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async (i) => {
            if (i.customId === 'painelSelect') {
                if (i.values[0] === 'configCargo') {
                    await i.reply({ content: 'Mencione o cargo que deseja configurar:', ephemeral: true });
                    const cargoFilter = m => m.author.id === interaction.user.id;

const collected = await interaction.channel.awaitMessages({ filter: cargoFilter, max: 1, time: 30000 });

                    const cargo = collected.first().mentions.roles.first();
                    if (!cargo) {
                        return i.followUp({ content: '❌ Você não mencionou um cargo válido!', ephemeral: true });
                    }

                    db.set(`configCargo_${interaction.guild.id}`, cargo.id);
                    i.followUp({ content: `✅ Cargo configurado com sucesso: ${cargo}`, ephemeral: true });
                }

                if (i.values[0] === 'configEmbed') {
                    const modal = new ModalBuilder()
                        .setCustomId('configEmbedModal')
                        .setTitle('Configurar Embed')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('titulo')
                                    .setLabel('Título')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(true)
                            ),
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('descricao')
                                    .setLabel('Descrição')
                                    .setStyle(TextInputStyle.Paragraph)
                                    .setRequired(true)
                            ),
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('cor')
                                    .setLabel('Cor (Hexadecimal) (Opcional)')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(false)
                            ),
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('imagem')
                                    .setLabel('Imagem (URL) (Opcional)')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(false)
                            )
                        );

                    await i.showModal(modal);

                    const modalSubmit = await i.awaitModalSubmit({ time: 30000 });
                    const titulo = modalSubmit.fields.getTextInputValue('titulo');
                    const descricao = modalSubmit.fields.getTextInputValue('descricao');
                    let cor = modalSubmit.fields.getTextInputValue('cor') || null;
                    let imagem = modalSubmit.fields.getTextInputValue('imagem') || null;

                    if (cor && !/^#[0-9A-Fa-f]{6}$/.test(cor)) {
                        return modalSubmit.reply({ content: '❌ Cor inválida! Use um código hexadecimal ou deixe em branco.', ephemeral: true });
                    }

                    if (imagem && !imagem.startsWith('https://')) {
                        imagem = null;
                    }

                    db.set(`configEmbed_${interaction.guild.id}`, { titulo, descricao, cor, imagem });
                    modalSubmit.reply({ content: '✅ Embed configurada com sucesso!', ephemeral: true });
                }

                if (i.values[0] === 'postarEmbed') {
                    const cargoId = db.get(`configCargo_${interaction.guild.id}`);
                    const embedConfig = db.get(`configEmbed_${interaction.guild.id}`);

                    if (!cargoId || !embedConfig) {
                        return i.reply({ content: '❌ Configure um cargo e uma embed antes de postar!', ephemeral: true });
                    }

                    const cargo = interaction.guild.roles.cache.get(cargoId);
                    if (!cargo) {
                        db.delete(`configCargo_${interaction.guild.id}`);
                        return i.reply({ content: '❌ O cargo configurado não existe mais no servidor!', ephemeral: true });
                    }

                    const embed = {
                        title: embedConfig.titulo,
                        description: embedConfig.descricao,
                        color: embedConfig.cor ? parseInt(embedConfig.cor.replace('#', ''), 16) : null,
                        image: embedConfig.imagem ? { url: embedConfig.imagem } : null
                    };

                    const selectMenu = new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                                .setCustomId('cargoSelect')
                                .setPlaceholder('Selecione uma ação')
                                .addOptions([
                                    { label: '➕ Adicionar Cargo', value: 'adicionarCargo' },
                                    { label: '➖ Remover Cargo', value: 'removerCargo' }
                                ])
                        );

                    await i.reply({ content: 'Mencione o canal onde a embed será enviada:', ephemeral: true });
                    const canalFilter = m => m.author.id === interaction.user.id;

const collected = await interaction.channel.awaitMessages({ filter: canalFilter, max: 1, time: 30000 });

                    const canal = collected.first().mentions.channels.first();
                    if (!canal) {
                        return i.followUp({ content: '❌ Você não mencionou um canal válido!', ephemeral: true });
                    }

                    await canal.send({ embeds: [embed], components: [selectMenu] });
                    i.followUp({ content: `✅ Embed enviada no canal ${canal}`, ephemeral: true });

                    const buttonCollector = canal.createMessageComponentCollector({ time: 60000 });

                    buttonCollector.on('collect', async (btnInteraction) => {
                        const member = btnInteraction.guild.members.cache.get(btnInteraction.user.id);

                        if (btnInteraction.values[0] === 'adicionarCargo') {
                            if (member.roles.cache.has(cargo.id)) {
                                return btnInteraction.reply({ content: '❌ Você já possui este cargo!', ephemeral: true });
                            }

                            await member.roles.add(cargo);
                            btnInteraction.reply({ content: `✅ Cargo ${cargo.name} adicionado com sucesso!`, ephemeral: true });
                        }

                        if (btnInteraction.values[0] === 'removerCargo') {
                            if (!member.roles.cache.has(cargo.id)) {
                                return btnInteraction.reply({ content: '❌ Você não possui este cargo!', ephemeral: true });
                            }

                            await member.roles.remove(cargo);
                            btnInteraction.reply({ content: `✅ Cargo ${cargo.name} removido com sucesso!`, ephemeral: true });
                        }
                    });
                }
            }
        });
    }
};