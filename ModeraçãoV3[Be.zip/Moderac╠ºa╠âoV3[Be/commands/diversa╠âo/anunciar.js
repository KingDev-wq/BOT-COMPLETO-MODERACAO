const { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  EmbedBuilder, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle 
} = require('discord.js');
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('anunciar')
    .setDescription('[📢] Crie um anúncio totalmente configurável.'),

  async execute(interaction) {
    if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}

    const embedConfig = {
      title: null,
      description: null,
      footer: null,
      color: null,
      image: null
    };
    let mensagemTexto = null;
    let embedPronto = false;

    const painelInicial = () => new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('visualizar_configuracao')
          .setLabel('👀 Ver Configuração')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('yconfig_embed')
          .setLabel('🖌️ Configurar Embed')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('configurar_mensagem')
          .setLabel('✏️ Configurar Mensagem')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('anunciar')
          .setLabel('📢 Anunciar')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.reply({
      content: 'Escolha uma ação abaixo:',
      components: [painelInicial()],
      ephemeral: true
    });

    const filter = i => i.user.id === interaction.user.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 600000 });

    const atualizarBotoes = () => new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('enviar_mensagem')
          .setLabel('✉️ Enviar Mensagem')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(!mensagemTexto),
        new ButtonBuilder()
          .setCustomId('yenviar_embed')
          .setLabel('📑 Enviar Embed')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(!embedPronto)
      );

    collector.on('collect', async i => {
      if (i.customId === 'yconfig_embed') {
        const modal = new ModalBuilder()
          .setCustomId('modal_configurar_embed')
          .setTitle('Configurar Embed')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('titulo')
                .setLabel('Título (Obrigatório)')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('descricao')
                .setLabel('Descrição (Obrigatória)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('cor')
                .setLabel('Cor (Hexadecimal - Opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('imagem')
                .setLabel('Imagem (URL - Opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('rodape')
                .setLabel('Rodapé (Opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            )
          );
        await i.showModal(modal);
      } else if (i.customId === 'configurar_mensagem') {
        const modal = new ModalBuilder()
          .setCustomId('modal_configurar_mensagem')
          .setTitle('Configurar Mensagem')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('mensagem_texto')
                .setLabel('Mensagem (Obrigatório)')
                .setStyle(TextInputStyle.Paragraph)
                .setMaxLength(4000)
                .setRequired(true)
            )
          );
        await i.showModal(modal);
      } else if (i.customId === 'visualizar_configuracao') {
        const embedVisualizacao = new EmbedBuilder()
          .setTitle(embedConfig.title || 'Título Não Configurado')
          .setDescription(embedConfig.description || 'Descrição Não Configurada')
          .setFooter({ text: embedConfig.footer || 'Rodapé Não Configurado' })
          .setColor(embedConfig.color || 0x7289da);

        if (embedConfig.image) embedVisualizacao.setImage(embedConfig.image);

        await i.reply({
          content: mensagemTexto || 'Mensagem não configurada.',
          embeds: [embedVisualizacao],
          ephemeral: true
        });
      } else if (i.customId === 'anunciar') {
        await i.reply({
          content: 'Escolha o que deseja enviar:',
          components: [atualizarBotoes()],
          ephemeral: true
        });

        const envioFilter = b => b.user.id === interaction.user.id;
        const envioCollector = interaction.channel.createMessageComponentCollector({ envioFilter, max: 1, time: 30000 });

        envioCollector.on('collect', async button => {
          await button.reply({ content: '📌 Mencione o canal onde deseja enviar o anúncio.', ephemeral: true });

          const canalFilter = m => m.author.id === interaction.user.id && m.mentions.channels.size > 0;
          const canalCollector = interaction.channel.createMessageCollector({ filter: canalFilter, max: 1, time: 30000 });

          canalCollector.on('collect', async msg => {
            const canal = msg.mentions.channels.first();

            if (canal) {
              if (button.customId === 'enviar_mensagem') {
                await canal.send(mensagemTexto);
              } else if (button.customId === 'yenviar_embed') {

  const embedEnvio = new EmbedBuilder()

    .setTitle(embedConfig.title)

    .setDescription(embedConfig.description)

    .setFooter({ text: embedConfig.footer })

    .setColor(embedConfig.color);

  if (embedConfig.image) embedEnvio.setImage(embedConfig.image);

  await canal.send({ embeds: [embedEnvio] });


  embedConfig.title = null;

  embedConfig.description = null;

  embedConfig.footer = null;

  embedConfig.color = null;

  embedConfig.image = null;

  embedPronto = false;

}

              mensagemTexto = null;
              await button.followUp({ content: `✅ Anúncio enviado no canal ${canal}.`, ephemeral: true });
            } else {
              await button.followUp({ content: '❌ Canal não encontrado. Tente novamente.', ephemeral: true });
            }
          });

          canalCollector.on('end', (collected, reason) => {
            if (reason === 'time') {
              button.followUp({ content: '⏰ Tempo esgotado. Nenhum canal foi mencionado.', ephemeral: true });
            }
          });
        });
      }
    });

    interaction.client.on('interactionCreate', async modalInteraction => {
      if (!modalInteraction.isModalSubmit()) return;

      if (modalInteraction.customId === 'modal_configurar_embed') {
        const titulo = modalInteraction.fields.getTextInputValue('titulo');
        const descricao = modalInteraction.fields.getTextInputValue('descricao');
        const cor = modalInteraction.fields.getTextInputValue('cor');
        const imagem = modalInteraction.fields.getTextInputValue('imagem');
        const rodape = modalInteraction.fields.getTextInputValue('rodape');

        if (cor && !/^#([0-9A-F]{3}){1,2}$/i.test(cor)) {
          return modalInteraction.reply({
            content: '❌ Cor inválida! Use o formato hexadecimal (ex.: #FF5733).',
            ephemeral: true
          });
        }
        if (imagem && !/^https:\/\//i.test(imagem)) {
          return modalInteraction.reply({
            content: '❌ URL inválida! O link da imagem deve começar com "https://".',
            ephemeral: true
          });
        }

        embedConfig.title = titulo;
        embedConfig.description = descricao;
        embedConfig.color = cor ? parseInt(cor.replace('#', ''), 16) : 0x7289da;
        embedConfig.image = imagem || null;
        embedConfig.footer = rodape || null;
        embedPronto = true;

        await modalInteraction.reply({
          content: '✅ Embed configurado com sucesso!',
          ephemeral: true
        });
      } else if (modalInteraction.customId === 'modal_configurar_mensagem') {
        mensagemTexto = modalInteraction.fields.getTextInputValue('mensagem_texto');

        await modalInteraction.reply({
          content: '✅ Mensagem configurada com sucesso!',
          ephemeral: true
        });
      }
    });
  }
};