const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pedrapapeltesoura')
    .setDescription('Inicie um jogo de Pedra, Papel e Tesoura'),
  async execute(interaction) {
    const host = interaction.user;
    let game = {
      host,
      player2: null,
      choices: {},
      lastWinner: 'Ninguém',
    };

    const embed = new EmbedBuilder()
      .setTitle('🎮 Pedra, Papel e Tesoura')
      .setDescription(
        `**Participantes:**\n${host}\nAguardando jogador...\n\nPressione **Iniciar** para começar.\n\n**Ganhador passado:** ${game.lastWinner}`
      )
      .setColor(0x00ae86);

    const initialButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('start')
        .setLabel('✅ Iniciar')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('join')
        .setLabel('👥 Entrar')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('leave')
        .setLabel('❌ Sair')
        .setStyle(ButtonStyle.Danger)
        .setDisabled(true)
    );

    const gameButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('pedra')
        .setLabel('🪨 Pedra')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId('papel')
        .setLabel('📄 Papel')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId('tesoura')
        .setLabel('✂️ Tesoura')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(true)
    );

    await interaction.reply({
      embeds: [embed],
      components: [initialButtons],
    });

    const filter = (i) => i.isButton();
    const collector = interaction.channel.createMessageComponentCollector({
      filter,
      time: 60000,
    });

    collector.on('collect', async (i) => {
      try {
        if (i.customId === 'start') {
          if (i.user.id !== host.id) {
            return i.reply({
              content: '❌️ | Você não executou o comando!',
              ephemeral: true,
            });
          }

          if (!game.player2) {
            return i.reply({
              content: '❌️ | Aguarde outro jogador para iniciar.',
              ephemeral: true,
            });
          }

          embed.setDescription(
            `**Participantes:**\n${host}\n${game.player2}\n\nEscolha Pedra, Papel ou Tesoura!`
          );
          gameButtons.components.forEach((button) =>
            button.setDisabled(false)
          );

          await i.update({
            embeds: [embed],
            components: [gameButtons],
          });
        }

        if (i.customId === 'join') {
          if (i.user.id === host.id || i.user.id === game.player2?.id) {
            return i.reply({
              content: '❌️ | Você já está participando!',
              ephemeral: true,
            });
          }

          if (game.player2) {
            return i.reply({
              content: '❌️ | Já há dois jogadores no jogo.',
              ephemeral: true,
            });
          }

          game.player2 = i.user;
          embed.setDescription(
            `**Participantes:**\n${host}\n${game.player2}\n\nPressione **Iniciar** para começar.`
          );
          initialButtons.components[2].setDisabled(false);

          await i.update({
            embeds: [embed],
            components: [initialButtons],
          });
        }

        if (i.customId === 'leave') {
          if (i.user.id !== game.player2?.id) {
            return i.reply({
              content: '❌️ | Você não está no jogo.',
              ephemeral: true,
            });
          }

          game.player2 = null;
          embed.setDescription(
            `**Participantes:**\n${host}\nAguardando jogador...\n\nPressione **Iniciar** para começar.\n\n**Ganhador passado:** ${game.lastWinner}`
          );
          initialButtons.components[2].setDisabled(true);

          await i.update({
            embeds: [embed],
            components: [initialButtons],
          });
        }

        if (['pedra', 'papel', 'tesoura'].includes(i.customId)) {
          if (!game.player2) {
            return i.reply({
              content: '❌️ | Aguarde outro jogador para iniciar.',
              ephemeral: true,
            });
          }

          if (game.choices[i.user.id]) {
            return i.reply({
              content: `❌️ | Você já escolheu **${game.choices[i.user.id]}**!`,
              ephemeral: true,
            });
          }

          game.choices[i.user.id] = i.customId;

          await i.reply({
            content: `✅️ | Você escolheu **${i.customId}**.`,
            ephemeral: true,
          });

          if (Object.keys(game.choices).length === 2) {
  const hostChoice = game.choices[host.id];
  const player2Choice = game.choices[game.player2.id];

  let result;
  if (hostChoice === player2Choice) {
    result = `🎉 | Empate! Ambos escolheram **${hostChoice}**.`;
    game.lastWinner = 'Ninguém';
  } else if (
    (hostChoice === 'pedra' && player2Choice === 'tesoura') ||
    (hostChoice === 'tesoura' && player2Choice === 'papel') ||
    (hostChoice === 'papel' && player2Choice === 'pedra')
  ) {
    result = `🎉 | **${host.username}** venceu com **${hostChoice}** contra **${player2Choice}**!`;
    game.lastWinner = host.username;
  } else {
    result = `🎉 | **${game.player2.username}** venceu com **${player2Choice}** contra **${hostChoice}**!`;
    game.lastWinner = game.player2.username;
  }

  embed.setDescription(
    `${result}\n\n**Ganhador passado:** ${game.lastWinner}`
  );

  await interaction.editReply({
    embeds: [embed],
    components: [],
  });

  setTimeout(async () => {
    embed.setDescription(
      `**Participantes:**\n${host}\nAguardando jogador...\n\nPressione **Iniciar** para começar.\n\n**Ganhador passado:** ${game.lastWinner}`
    );
    initialButtons.components[2].setDisabled(true);
    await interaction.editReply({
      embeds: [embed],
      components: [initialButtons],
    });

    game = {
      host,
      player2: null,
      choices: {},
      lastWinner: game.lastWinner,
    };
  }, 6000);
}
        }
      } catch (error) {
        console.error(error);
      }
    });

    collector.on('end', async () => {
      embed.setDescription('❌ | O jogo foi encerrado devido à inatividade.');
      await interaction.editReply({
        embeds: [embed],
        components: [],
      });
    });
  },
};