const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { JsonDatabase } = require("wio.db");
const fs = require('fs');
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('painellog')
    .setDescription('[🕵] Gera um painel para configurar logs'),

  async execute(interaction) {
    if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}


    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle('Configuração de Logs')
      .setDescription('Clique no botão abaixo para configurar os logs.')
      .setFooter({ text: `Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    const button = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('config_logs')
        .setLabel('Configurar Logs')
        .setEmoji('⚙️')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({ embeds: [embed], components: [button] });
  },
};