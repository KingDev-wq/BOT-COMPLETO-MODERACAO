const { SlashCommandBuilder } = require('discord.js');
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: './databases/perms.json' });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('roleid')
        .setDescription('Obtém o ID de um cargo.')
        .addRoleOption(option => 
            option.setName('cargo')
                .setDescription('Selecione o cargo.')
                .setRequired(true)
        ),
    async execute(interaction) {
      const channel = interaction.channel;

        if (!dbPerms.has(interaction.user.id)) {

    return interaction.reply({

        content: '❌ | Você não possui permissão para usar este comando.',

        ephemeral: true

    });

}
      
        const role = interaction.options.getRole('cargo');
        await interaction.reply({ content: `O ID do cargo **${role.name}** é: \`${role.id}\``, ephemeral: true });
    },
};