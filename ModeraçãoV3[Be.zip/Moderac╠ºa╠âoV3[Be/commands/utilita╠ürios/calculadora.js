const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('calculadora')
        .setDescription('Abre uma calculadora interativa com botões.'),

    async execute(interaction) {
        let currentExpression = '';
        const maxCharacters = 25;

        const createEmbed = () => {
            return new EmbedBuilder()
                .setTitle('Calculadora')
                .setDescription(currentExpression || 'Clique nos botões abaixo para começar.')
                .setColor('Blue');
        };

        const isExpressionValid = () => {
            return /[+\-×÷]/.test(currentExpression) && /\d+/.test(currentExpression);
        };

        const calculateResult = () => {
            const sanitizedExpression = currentExpression
                .replace(/×/g, '*')
                .replace(/÷/g, '/');
            try {
                return eval(sanitizedExpression).toString();
            } catch {
                return 'Erro';
            }
        };

        const buttons = [
            ['C', '<', '÷', '×'],
            ['7', '8', '9', '+'],
            ['4', '5', '6', '-'],
            ['1', '2', '3', '='],
            ['⠀', '0', '⠀']
        ];

        const rows = buttons.map(row =>
            new ActionRowBuilder().addComponents(
                row.map((button, index) =>
                    new ButtonBuilder()
                        .setCustomId(button === '⠀' ? `decorative-${index}` : button)
                        .setLabel(button)
                        .setStyle(button === 'C' || button === '<' ? ButtonStyle.Danger : ButtonStyle.Primary)
                        .setDisabled(button === '⠀')
                )
            )
        );

        const message = await interaction.reply({
            embeds: [createEmbed()],
            components: rows,
            fetchReply: true
        });

        const collector = message.createMessageComponentCollector({
            time: 300000
        });

        collector.on('collect', async btnInteraction => {
            if (btnInteraction.user.id !== interaction.user.id) {
                return btnInteraction.reply({
                    content: '❌ | Você deve executar sua própria calculadora!',
                    ephemeral: true
                });
            }

            const buttonId = btnInteraction.customId;

            if (buttonId === 'C') {
                currentExpression = '';
            } else if (buttonId === '<') {
                currentExpression = currentExpression.slice(0, -1);
            } else if (buttonId === '=') {
                if (isExpressionValid()) {
                    currentExpression = calculateResult();
                } else {
                    return btnInteraction.reply({
                        content: '❌ | Você não pode calcular sem uma operação válida!',
                        ephemeral: true
                    });
                }
            } else {
                if (currentExpression.length < maxCharacters) {
                    currentExpression += buttonId;
                } else {
                    return btnInteraction.reply({
                        content: '❌ | O limite de 25 caracteres foi atingido!',
                        ephemeral: true
                    });
                }
            }

            await btnInteraction.update({
                embeds: [createEmbed()]
            });
        });

        collector.on('end', async () => {
            message.edit({
                components: rows.map(row => {
                    row.components.forEach(button => button.setDisabled(true));
                    return row;
                })
            });
        });
    }
};